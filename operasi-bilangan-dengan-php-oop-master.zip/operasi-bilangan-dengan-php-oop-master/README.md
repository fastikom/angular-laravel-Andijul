# Nurul Imam Source Code

Source Code dari Artikel Pembelajaran PHP OOP Sesi [**Membuat Operasi Bilangan Sederhana Dengan PHP OOP**](http://www.nurulimam.com/2014/10/latihan-membuat-operasi-bilangan-dengan-oop.html) yang didukung oleh [Banten IT Solutions](http://www.banten-it.com).

## Index Sesi Pembelajaran [OOP Pada PHP](http://www.nurulimam.com/2014/10/belajar-php-oop-object-oriented-programming-pemula.html)

* [Pengenalan Class, Property & Method](http://www.nurulimam.com/2014/10/mengenal-class-property-dan-method.html)
* [Pengenalan Constructor Dan Desctructor](http://www.nurulimam.com/2014/10/mengenal-constructors-destructors.html)
* [Aksesbilitas Property & Method Dengan Encapsulation](http://www.nurulimam.com/2014/10/aksesbilitas-property-method-dengan-encapsulation.html)
* [Inheritance / Pewarisan Dalam OOP](http://www.nurulimam.com/2014/10/inheritance-pewarisan-dalam-oop.html)
* [Membuat Operasi Bilangan Sederhana Dengan PHP OOP](http://www.nurulimam.com/2014/10/latihan-membuat-operasi-bilangan-dengan-oop.html)
* [Anonymous Function / Lambda & Closure](http://www.nurulimam.com/2014/10/php5-anonymous-function-lambda-closure.html)

Jika ingin menawarkan project, atau ingin belajar website, silahkan hubungi saya di halaman [Hubungi Kami](http://www.nurulimam.com/hubungi).